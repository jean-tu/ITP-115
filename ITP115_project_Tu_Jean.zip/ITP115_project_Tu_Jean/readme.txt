THIS APPLICATION MUST BE RUN ON A MAC device.

The idea of this is that the user will be able to choose whether or not they would like to play the MadLib version
or if they would like to create their own story. The own story is pretty simple where they would just type the story
that they want into the text box and then click the read button and it will be read out to them and they have the
choice of whether or not they want to save the story or continue editing.

The Stories folder contains all of the stories for the MadLibs. The file "master.txt" is the file with all of the
other stories titles to know which stories to read in.

HOW TO RUN
    1) Go to "main.py"
    2) Run the file
    3) Select which option you would like to do (either Create your own story or the madLibs)
    4a) Create your own
        5) You want to type your story into the box that is presented
        6) You can then Read your story or save it
    4b) Mad Libs
        5) Replace the words with the underscores _around_ them
        6) Read the story or save it

I tested my program by coming in to OH for Brandon on Friday 5/5 around 2:10 PM and the speech dictation aspect worked.         